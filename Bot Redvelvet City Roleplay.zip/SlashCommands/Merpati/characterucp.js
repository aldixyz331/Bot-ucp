const { Client, CommandInteraction, MessageEmbed } = require("discord.js");
const MysqlMerpati = require("../../Mysql");

module.exports = {
  name: "playerucp",
  description: "Cek karakter User Control Panel",
  type: "",
  options: [
    {
      name: "playerucp-account",
      description: "Nama akun UCP yang akan diperiksa karakternya!",
      type: "USER",
      required: true,
    },
  ],
  /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   * @param {String[]} args
   */
  run: async (client, interaction, args) => {
    if (!interaction.member.permissions.has("ADMINISTRATOR")) {
      return interaction.reply({
        content: "You don't have permission to use this command!",
        ephemeral: true,
      });
    }

    try {
      const getAccount = interaction.options.getUser("playerucp-account");

      const roww = await new Promise((resolve, reject) => {
        MysqlMerpati.query(
          `SELECT * FROM playerucp WHERE DiscordID = '${getAccount.id}'`,
          (err, result) => {
            if (err) reject(err);
            resolve(result);
          }
        );
      });

      if (roww[0]) {
        const row = await new Promise((resolve, reject) => {
          MysqlMerpati.query(
            `SELECT * FROM players WHERE ucp = '${roww[0].ucp}' LIMIT 3`,
            (err, result) => {
              if (err) reject(err);
              resolve(result);
            }
          );
        });

        const msgChar = new MessageEmbed()
          .setAuthor({
            name: "Redvelvet City Roleplay",
            iconURL: client.config.ICON_URL,
          })
          .setDescription(
            `- Data Akun User Control Panel -\n• Karakter 1: ${
              row[0]?.ucp || "Tidak Ditemukan"
            }\n• Karakter 2: ${
              row[1]?.ucp || "Tidak Ditemukan"
            }\n• Karakter 3: ${row[1]?.ucp || "Tidak Ditemukan"}`
          )
          .setColor("#0AB976")
          .setFooter({ text: "Redvelvet City Roleplay" })
          .setTimestamp();

        interaction.reply({ embeds: [msgChar] });
        console.log(
          `1. ${row[0]?.ucp || "Tidak Ditemukan"}\n2. ${
            row[1]?.ucp || "Tidak Ditemukan"
          }\n3. ${row[1]?.ucp || "Tidak Ditemukan"}`
        );
      } else {
        IntError(
          interaction,
          "Maaf user yang anda tag tidak memiliki akun UCP!"
        );
      }
    } catch (error) {
      console.error("Error in playerucp command:", error);
      IntError(
        interaction,
        "Terjadi kesalahan saat menjalankan perintah. Silakan coba lagi nanti."
      );
    }
  },
};
