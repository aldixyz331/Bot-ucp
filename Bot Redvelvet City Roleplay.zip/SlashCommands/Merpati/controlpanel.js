const {
  Client,
  CommandInteraction,
  MessageEmbed,
  MessageButton,
  MessageActionRow,
} = require("discord.js");

module.exports = {
  name: "controlpanel",
  description: "Menampilkan Panel Register Redvelvet City Roleplay",
  /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   * @param {String[]} args
   */
  run: async (client, interaction, args) => {
    if (!interaction.member.permissions.has("ADMINISTRATOR")) {
      return interaction.reply({
        content: "Only administrators can use this command!",
        ephemeral: true,
      });
    }

    const msgEmbed = new MessageEmbed()
      .setTitle("Registration UCP")
      .setAuthor({ name: "Redvelvet City Account Manager", iconURL: client.config.ICON_URL })
      .setColor("#B5FFB5")
      .setDescription(
        "Channel ini merupakan tempat dimana kamu dapat mengatur akun UCP kamu sendiri. Terdapat beberapa hal yang harus kamu ketahui, diantaranya:"
      )
      .addFields({
        name: "__**Ambil Karcis**__ 🎟️",
        value:
          "> Sebagaimana dengan judulnya, tombol ini merupakan tombol dimana anda dapat membuat akun UCP.",
      })
      .addFields({
        name: "__**Cek Karcis**__ 🕵️",
        value:
          "> Sesuai dengan judulnya, tombol ini berguna untuk mengecek karcis yang pernah anda daftarkan sebelumnya.",
      })
      .addFields({
        name: "__**Ubah Password**__ 🔐",
        value:
          "> Sesuai dengan judulnya, tombol ini merupakan tempat apabila kamu lupa kata sandi atau ingin mengganti kata sandi.",
      }) 
      .addFields({
        name: "__**Reffund Karcis**__ ⚙️",
        value:
          "> Apabila anda sudah pernah mendaftarkan UCP sebelumnya lalu anda keluar dari discord kami maka anda dapat mengambil kembali role dengan tombol ini.",
      })
      .setFooter({ text: "Full Copyright Redvelvet City Roleplay 2024 " })
      .setTimestamp();

    const Buttons = new MessageActionRow().addComponents(
      new MessageButton()
        .setCustomId("button-register")
        .setLabel("Ambil Karcis")
        .setStyle("PRIMARY")
        .setEmoji("🎟️"),

      new MessageButton()
        .setCustomId("button-resendcode")
        .setLabel("Cek Karcis")
        .setStyle("PRIMARY")
        .setEmoji("🕵️"),

      new MessageButton()
        .setCustomId("button-reset")
        .setLabel("Ubah Password")
        .setStyle("DANGER")
        .setEmoji("🔐"),

      new MessageButton()
        .setCustomId("button-reffrole")
        .setLabel("Reffund Karcis")
        .setStyle("SECONDARY")
        .setEmoji("⚙️")
    );

    await interaction.channel.send({
      embeds: [msgEmbed],
      components: [Buttons],
    });

    await interaction.reply({
      content: "Berhasil mengirim pesan",
      ephemeral: true,
    });
  },
};
