const { Client, CommandInteraction } = require("discord.js");
const MysqlMerpati = require("../../Mysql");
require("../../Functions")

module.exports = {
    name: "renameplayerucp",
    description: "Untuk mengubah nama Akun User Control Panel",
    type: "",
    options: [
        {
            name: "playerucp-account",
            description: "Nama akun UCP yang akan diubah Namanya!",
            type: "USER",
            required: true,
        },
        {
            name: "newname-account",
            description: "Nama baru untuk akun UCP!",
            type: "STRING",
            required: true,
        },
    ],
    /**
     *
     * @param {Client} client
     * @param {CommandInteraction} interaction
     * @param {String[]} args
     */
    run: async (client, interaction, args) => {
        if (!interaction.member.permissions.has("ADMINISTRATOR")) {
            return interaction.reply({
            content: "You don't have permission to use this command!",
            ephemeral: true,
            });
        }

        const getAccount = interaction.options.getUser("playerucp-account");
        const getName = interaction.options.getString("newname-account");

        MysqlMerpati.query(`SELECT * FROM playerplayerucp WHERE discordID = '${getAccount.id}'`, async (err, roww) => {
            if (roww[0]) {
                MysqlMerpati.query(`SELECT * FROM playerplayerucp WHERE playerucp = '${getName}'`, async(err, row) => {
                    if(row[0]) {
                        IntError(interaction, "Maaf nama tersebut telah dipakai oleh user lain!, Silahkan mencari yang baru karena yang lama belum tentu menyukaimu :)");
                    } else {
                        IntAdmin(interaction, `Nama User Control Panel (${roww[0].playerucp}) Berhasil diubah menjadi (${getName}) Oleh admin <@${interaction.user.id}>`);
                        MysqlMerpati.query(`UPDATE playerplayerucp SET UCP = '${getName}' WHERE discordID = '${getAccount.id}'`);
                    }
                })
            } else {
                IntAdmin(interaction, "Maaf akun yang anda tag tidak memiliki akun User Control Panel!");
            }
        })
    },
};
