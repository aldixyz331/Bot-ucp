const { Client, CommandInteraction } = require("discord.js");
const MysqlMerpati = require("../../Mysql");
require("../../Functions");

module.exports = {
  name: "removeplayerucp",
  description: "Untuk menghapus akun playerucp server Redvelvet City Roleplay!",
  type: "",
  options: [
    {
      name: "playerucp-account",
      description: "Nama akun UCP yang akan dihapus!",
      type: "STRING",
      required: true,
    },
  ],
  /**
   *
   * @param {Client} client
   * @param {CommandInteraction} interaction
   * @param {String[]} args
   */
  run: async (client, interaction, args) => {
    if (!interaction.member.permissions.has("ADMINISTRATOR"))
      return IntPerms(interaction);
    const playerucpName = interaction.options.getString("playerucp-account");

    MysqlMerpati.query(
      `SELECT * FROM playerplayerucp WHERE playerucp = '${playerucpName}'`,
      async (err, row) => {
        if (row[0]) {
          IntAdmin(
            interaction,
            `Akun User Control Panel dengan Nama **${playerucpName}** Telah berhasil di hapus oleh Admin **<@${interaction.user.id}>**`
          );
          await MysqlMerpati.query(
            `DELETE FROM playerplayerucp WHERE playerucp = '${playerucpName}'`
          );
        } else {
          IntAdmin(
            interaction,
            "Akun dengan User Control Panel tersebut tidak ditemukan!"
          );
        }
      }
    );
  },
};
