function pengumuman(user, channel, params, client) {
  // Check if the channel is the correct one
  if (channel.id !== "1324095350235201552") return;

  // Get the info channel
  const infoChannel = channel.guild.channels.cache.get("1324095350235201552");

  // Check if params is empty or undefined
  if (!params || params.length === 0) {
    return channel.send("```Usage:!pengumuman [Text]```");
  }

  // Join the params into a single string
  const message = params.join(" ");

  // Send the message to the info channel
  infoChannel
    .send(message)
    .then(() => {
      // Send a success message to the original channel
      channel.send(
        "```Your announcement has been sent successfully by Redvelvet City RoleplayBot!```"
      );
    })
    .catch((error) => {
      console.error(`Error sending announcement: ${error}`);
      channel.send("```Error sending announcement. Please try again later.```");
    });
}
