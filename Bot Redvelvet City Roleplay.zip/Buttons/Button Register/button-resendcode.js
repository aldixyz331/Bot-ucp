const { CommandInteraction, MessageEmbed } = require("discord.js");
const MysqlMerpati = require("../../Mysql");
const client = require("../../Merpati");

module.exports = {
  id: "button-resendcode",
  /**
   * @param {CommandInteraction} interaction
   */
  run: async (interaction) => {
    const userid = interaction.user.id;
    MysqlMerpati.query(
      `SELECT * FROM playerucp WHERE DiscordID = '${userid}'`,
      async (error, row) => {
        if (row[0]) {
          const msgEmbed = new MessageEmbed()
            .setAuthor({
              name: "Cek Akun | Redvelvet City Roleplay",
              iconURL: client.config.ICON_URL,
            })
            .setDescription(
              `:white_check_mark: **Berhasil!**\nBerikut adalah detail dari akun UCP anda:\n\n**Nama UCP**\n${row[0].ucp}\n\n** Kode Verifikasi**\n${row[0].pin}\n\n**Pemilik Akun**\nUser ID : **${userid}**\nUsername DC : **${interaction.user.tag}**\n\n**Status**\nTerverifikasi\n\n**Note**\nJangan beritahu informasi ini kepada orang lain!`
            )
            .setColor("#0AB976")
            .setFooter({ text: "Redvelvet City Roleplay" })
            .setTimestamp();
          await interaction.user.send({ embeds: [msgEmbed] }).catch((error) => {
            interaction.reply({
              content:
                "```\nTidak dapat mengirimkan kode/pin Verifikasi akun playerucp anda, Silahkan gunakan command /resendcode jika sudah melakukan intruksi di bawah ini:\n- INTRUKSI OPEN DIRECT MESSAGE -\n• Tips Pertama, Kamu Pergi Ke Pengaturan Discord\n• Tips Ke Dua, Pilih Privacy & Safety\n• Tips Ke Tiga, Pilih Do Not Scan\n```",
              ephemeral: true,
            });
          });

          IntSucces(
            interaction,
            "Cek Akun | Redvelvet City Roleplay\n:white_check_mark: Berhasil!\n\n> Kami telah mengirimkan DM kepada anda, silahkan dibuka!\n\n**Redvelvet City Roleplay**\n_~MenyatukanSemua~_"
          );
        } else
          return IntError(
            interaction,
            ":x: **ERROR** \nAnda Belum pernah mengambil tiket di kota Redvelvet City Roleplay\nSilahkan daftarkan akun anda dengan cara ambil tiket\n\n**Redvelvet City Roleplay**\n_~MenyatukanSemua~_"
          );
      }
    );
  },
};
