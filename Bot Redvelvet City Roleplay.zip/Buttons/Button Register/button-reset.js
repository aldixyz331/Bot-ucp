const { CommandInteraction, MessageEmbed } = require("discord.js");
const MysqlMerpati = require("../../Mysql");
const client = require("../../Merpati");
const { IntSucces, IntError } = require("../../Functions");

module.exports = {
  id: "button-reset",
  /**
   * @param {CommandInteraction} interaction
   */
  run: async (interaction) => {
    const userid = interaction.user.id;

    MysqlMerpati.query(
      `SELECT * FROM playerucp WHERE DiscordID = '${userid}'`,
      async (error, row) => {
        if (!row[0]) {
          return IntError(
            interaction,
            ":x: **ERROR** \nAnda Belum pernah mengambil tiket di kota Redvelvet City Roleplay\nSilahkan daftarkan akun anda dengan cara ambil tiket\n\n**Redvelvet City Roleplay**\n_~MenyatukanSemua~_"
          );
        }

        // Reset password logic here
        MysqlMerpati.query(
          `SELECT * FROM playerucp WHERE password = '${userid}'`,
          async (err) => {
            if (err) {
              return IntError(
                interaction,
                ":x: **Error**\nGagal mereset password akun UCP. Silakan coba lagi."
              );
            }

            const msgEmbed = new MessageEmbed()
              .setAuthor({
                name: "Pemulihan akun | Redvelvet City Roleplay!",
                iconURL: client.config.ICON_URL,
              })
              .setDescription(
                `\n:warning: Peringatan!\nAnda telah meminta layanan lupa password. Jika ini bukan permintaan anda, maka abaikan saja pesan ini!\n\n***Kode Pemulihan***\n\`\`\`${row[0].verifycode}\`\`\`\nMasuklah ke server dan masukkan Kode Pemulihan untuk membuat ulang kata sandi!\n\n**Redvelvet City Roleplay**\n_~MenyatukanSemua~_`
              )
              .setColor("#0AB976")
              .setFooter({ text: "Redvelvet City Roleplay" })
              .setTimestamp();

            try {
              await interaction.reply({ embeds: [msgEmbed], ephemeral: true });
              IntSucces(
                interaction,
                "Pemulihan Akun | Redvelvet City Roleplay\n:white_check_mark: Berhasil!\n\n> Kami telah mengirimkan DM kepada anda, silahkan dibuka!\n\n**Redvelvet City Roleplay**\n_~MenyatukanSemua~_"
              );
            } catch (error) {
              IntError(
                interaction,
                ":x: **ERROR**\nGagal mengirim pesan. Pastikan pengaturan privasi Anda memperbolehkan pesan dari server ini."
              );
            }
          }
        );
      }
    );
  },
};
