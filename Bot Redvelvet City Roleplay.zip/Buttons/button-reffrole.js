const { CommandInteraction, MessageButton } = require("discord.js");
const MysqlMerpati = require("../Mysql");
const client = require("../Merpati");

module.exports = {
  id: "button-reffrole",
  /**
   * @param {CommandInteraction} interaction
   */
  run: async (interaction) => {
    const userid = interaction.user.id;

    MysqlMerpati.query(
      `SELECT * FROM playerucp WHERE DiscordID = '${userid}'`,
      async (err, rows) => {
        if (rows.length > 0) {
          // Jika Discord ID sudah terdaftar di tabel playerplayerucp
          const rUCP = interaction.guild.roles.cache.get(
            client.config.ROLE_UCP
          );
          interaction.member.roles.add(rUCP);

          // Tambahkan tindakan lain yang ingin Anda lakukan jika Discord ID sudah terdaftar
          IntSucces(
            interaction,
            `REFF ROLE Redvelvet City Roleplay\n:white_check_mark: **Berhasil!**\n\n> Akun Discord anda berhasil kami verifikasi sebagai pemain di Redvelvet City Roleplay\n> Mohon untuk tidak keluar lagi dari discord Redvelvet City Roleplay\n\n**Redvelvet City Roleplay**\n***Tersentuh Seni, Terpikat Cerita***`
          );
        } else {
          // Tindakan yang ingin Anda lakukan jika Discord ID belum terdaftar
          IntError(
            interaction,
            `**REFF ROLE | Redvelvet City Roleplay**\n:x: Error!\n\n> Anda belum pernah register / ambil tiket di Redvelvet City Roleplay, silahkan ambil tiket terlebih dahulu\n\n**Redvelvet City Roleplay**\n***Tersentuh Seni, Terpikat Cerita***`
          );
        }
      }
    );
  },
};
