const client = require("../Merpati");
const samp = require("samp-query");

// var connection = {
//     host: client.config.SERVER_IP,
//     port: client.config.SERVER_PORT
// }

function StatusActivityUpdate() {
  samp(connection, function (error, response) {
    if (error) {
      client.user.setActivity("Harajuku Life RoleplayUcp Bot", { type: "standby" });
    } else {
      client.user.setActivity(`Players: ${response.online}`, {
        type: "standby",
      });
    }
  });
}

client.on("ready", async () => {
  console.log(
    `\x1b[36m[BOT]: \x1b[0m(${client.user.tag}) Telah berhasil Aktif!`
  );
  setInterval(StatusActivityUpdate, 20000);
});
